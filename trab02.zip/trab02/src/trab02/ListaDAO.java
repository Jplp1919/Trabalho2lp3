package trab02;


public class ListaDAO {
    
}
