package trab02;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.sql.DataSource;
import com.mchange.v2.c3p0.ComboPooledDataSource;

public class ConnectionFactory {
    public DataSource datasource;
     public ConnectionFactory(){
        ComboPooledDataSource pooled = new ComboPooledDataSource();
        pooled.setJdbcUrl("jdbc:mysql://127.0.0.1:3306/loja_virtual?useTimezone=true&serverTimezone=UTC");
        pooled.setUser("root");
        pooled.setPassword("root");
        pooled.setMaxPoolSize(15);
        this.datasource = pooled;
     }
    public Connection establishConnection() throws SQLException  {
       /* return DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/loja_virtual?useTimezone=true&serverTimezone=UTC",
                "root", "root");*/
       
       return this.datasource.getConnection();
      
    }
}
