package trab02.doc;

import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import org.w3c.dom.Document;

public class DocumentReader {

    public void readEscritores(String path) {
     
    }
}
